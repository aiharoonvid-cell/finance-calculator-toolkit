/**
 * Shared input-validation and numeric helper utilities used by every
 * calculator in the toolkit. Centralising validation keeps error messages
 * consistent and makes the individual calculator functions easy to read.
 *
 * @packageDocumentation
 */

/**
 * Error thrown when a calculator receives invalid input.
 *
 * A dedicated error class lets consumers distinguish validation problems
 * from unexpected runtime errors.
 *
 * @example
 * ```ts
 * import { simpleInterest, ValidationError } from 'salary-finance-toolkit';
 *
 * try {
 *   simpleInterest({ principal: -1, rate: 5, years: 1 });
 * } catch (err) {
 *   if (err instanceof ValidationError) {
 *     console.error('Bad input:', err.message);
 *   }
 * }
 * ```
 */
export class ValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ValidationError';
    // Restore the prototype chain (needed when down-compiling from TS).
    Object.setPrototypeOf(this, ValidationError.prototype);
  }
}

/**
 * Asserts that a value is a finite number (not `NaN`, `Infinity`, `null`,
 * `undefined`, or a non-numeric type).
 *
 * @param value - The value to check.
 * @param name  - Parameter name, used in the error message.
 * @throws {@link ValidationError} If the value is not a finite number.
 */
export function assertNumber(value: unknown, name: string): asserts value is number {
  if (typeof value !== 'number' || Number.isNaN(value) || !Number.isFinite(value)) {
    throw new ValidationError(`"${name}" must be a finite number, received: ${String(value)}`);
  }
}

/**
 * Asserts that a number is greater than or equal to zero.
 *
 * @param value - The value to check.
 * @param name  - Parameter name, used in the error message.
 * @throws {@link ValidationError} If the value is negative or not a number.
 */
export function assertNonNegative(value: unknown, name: string): asserts value is number {
  assertNumber(value, name);
  if (value < 0) {
    throw new ValidationError(`"${name}" must be greater than or equal to 0, received: ${value}`);
  }
}

/**
 * Asserts that a number is strictly greater than zero.
 *
 * @param value - The value to check.
 * @param name  - Parameter name, used in the error message.
 * @throws {@link ValidationError} If the value is zero, negative, or not a number.
 */
export function assertPositive(value: unknown, name: string): asserts value is number {
  assertNumber(value, name);
  if (value <= 0) {
    throw new ValidationError(`"${name}" must be greater than 0, received: ${value}`);
  }
}

/**
 * Asserts that a value is an integer.
 *
 * @param value - The value to check.
 * @param name  - Parameter name, used in the error message.
 * @throws {@link ValidationError} If the value is not an integer.
 */
export function assertInteger(value: unknown, name: string): asserts value is number {
  assertNumber(value, name);
  if (!Number.isInteger(value)) {
    throw new ValidationError(`"${name}" must be an integer, received: ${value}`);
  }
}

/**
 * Asserts that a number falls within an inclusive range.
 *
 * @param value - The value to check.
 * @param name  - Parameter name, used in the error message.
 * @param min   - Inclusive lower bound.
 * @param max   - Inclusive upper bound.
 * @throws {@link ValidationError} If the value is outside `[min, max]`.
 */
export function assertInRange(
  value: unknown,
  name: string,
  min: number,
  max: number,
): asserts value is number {
  assertNumber(value, name);
  if (value < min || value > max) {
    throw new ValidationError(`"${name}" must be between ${min} and ${max}, received: ${value}`);
  }
}

/**
 * Rounds a number to a fixed number of decimal places while mitigating the
 * binary floating-point artefacts produced by a naive `Math.round`.
 *
 * @param value    - The number to round.
 * @param decimals - Number of decimal places (default `2`).
 * @returns The rounded number.
 *
 * @example
 * ```ts
 * round(1.005, 2); // 1.01
 * ```
 */
export function round(value: number, decimals = 2): number {
  if (!Number.isFinite(value)) return value;
  const factor = 10 ** decimals;
  return Math.round((value + Number.EPSILON) * factor) / factor;
}
