/**
 * Pay-period and compounding-frequency helpers shared across the payroll and
 * finance modules.
 *
 * @packageDocumentation
 */

import { ValidationError } from './validation';

/**
 * Supported frequencies mapped to the number of periods they represent in a
 * single year. Used for pay periods and interest compounding alike.
 */
export const PERIODS_PER_YEAR = {
  annual: 1,
  semiannual: 2,
  quarterly: 4,
  monthly: 12,
  semimonthly: 24,
  biweekly: 26,
  weekly: 52,
  daily: 365,
} as const;

/** Union of all supported frequency keys. */
export type Frequency = keyof typeof PERIODS_PER_YEAR;

/**
 * Resolves the number of periods per year for a given frequency.
 *
 * @param frequency - One of the supported {@link Frequency} keys.
 * @returns Number of periods in a year.
 * @throws {@link ValidationError} If the frequency is not recognised.
 *
 * @example
 * ```ts
 * periodsPerYear('monthly'); // 12
 * periodsPerYear('biweekly'); // 26
 * ```
 */
export function periodsPerYear(frequency: Frequency): number {
  const value = PERIODS_PER_YEAR[frequency];
  if (value === undefined) {
    throw new ValidationError(
      `Unknown frequency "${String(frequency)}". Valid options: ${Object.keys(PERIODS_PER_YEAR).join(', ')}`,
    );
  }
  return value;
}
