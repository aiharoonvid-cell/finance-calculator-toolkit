/**
 * Tax calculators: a generic progressive-bracket engine plus effective and
 * marginal rate helpers.
 *
 * @packageDocumentation
 */
export * from './progressiveTax';
export * from './effectiveTaxRate';
