/**
 * Effective and marginal tax-rate helpers.
 *
 * @packageDocumentation
 */

import { assertPositive, assertNonNegative, round } from '../utils/validation';
import { progressiveTax, type TaxBracket } from './progressiveTax';

/** Input for {@link effectiveTaxRate}. */
export interface EffectiveTaxRateInput {
  /** Gross / taxable income. */
  income: number;
  /** Total tax paid on that income. */
  taxPaid: number;
}

/**
 * Computes the effective (average) tax rate: `taxPaid / income * 100`.
 *
 * @param input - See {@link EffectiveTaxRateInput}.
 * @returns The effective tax rate as a percentage, rounded to 2 dp.
 * @throws {@link ValidationError} If inputs are invalid.
 *
 * @example
 * ```ts
 * effectiveTaxRate({ income: 50000, taxPaid: 9600 }); // 19.2
 * ```
 */
export function effectiveTaxRate(input: EffectiveTaxRateInput): number {
  const { income, taxPaid } = input;
  assertPositive(income, 'income');
  assertNonNegative(taxPaid, 'taxPaid');
  return round((taxPaid / income) * 100, 2);
}

/** Input for {@link marginalTaxRate}. */
export interface MarginalTaxRateInput {
  /** Taxable income. */
  income: number;
  /** Progressive tax brackets (see {@link TaxBracket}). */
  brackets: TaxBracket[];
}

/**
 * Returns the marginal tax rate — the rate applied to the next unit of income
 * — for a given income and bracket set.
 *
 * @param input - See {@link MarginalTaxRateInput}.
 * @returns The marginal rate as a percentage.
 * @throws {@link ValidationError} If inputs are invalid.
 *
 * @example
 * ```ts
 * marginalTaxRate({
 *   income: 50000,
 *   brackets: [
 *     { from: 0, to: 12000, rate: 0 },
 *     { from: 12000, to: 40000, rate: 20 },
 *     { from: 40000, rate: 40 },
 *   ],
 * }); // 40
 * ```
 */
export function marginalTaxRate(input: MarginalTaxRateInput): number {
  const { income, brackets } = input;
  return progressiveTax({ income, brackets }).marginalRate;
}
