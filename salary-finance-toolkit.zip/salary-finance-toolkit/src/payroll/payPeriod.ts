/**
 * Split an annual salary across an arbitrary pay frequency.
 *
 * @packageDocumentation
 */

import { assertPositive, round } from '../utils/validation';
import { periodsPerYear, type Frequency } from '../utils/frequency';

/** Input for {@link payPeriodSalary}. */
export interface PayPeriodInput {
  /** Annual gross salary. */
  annualSalary: number;
  /** Pay frequency. Default `'monthly'`. */
  frequency?: Frequency;
}

/** Result returned by {@link payPeriodSalary}. */
export interface PayPeriodResult {
  /** Gross pay per individual pay period. */
  perPeriod: number;
  /** Number of pay periods per year. */
  periodsPerYear: number;
  /** The frequency that was applied. */
  frequency: Frequency;
}

/**
 * Splits an annual salary into the gross amount paid in each pay period for a
 * given frequency (weekly, biweekly, semimonthly, monthly, etc.).
 *
 * @param input - See {@link PayPeriodInput}.
 * @returns A {@link PayPeriodResult}.
 * @throws {@link ValidationError} If the salary is not positive or the
 *   frequency is unknown.
 *
 * @example
 * ```ts
 * payPeriodSalary({ annualSalary: 52000, frequency: 'biweekly' });
 * // -> { perPeriod: 2000, periodsPerYear: 26, frequency: 'biweekly' }
 * ```
 */
export function payPeriodSalary(input: PayPeriodInput): PayPeriodResult {
  const { annualSalary, frequency = 'monthly' } = input;
  assertPositive(annualSalary, 'annualSalary');
  const periods = periodsPerYear(frequency);
  return { perPeriod: round(annualSalary / periods), periodsPerYear: periods, frequency };
}
