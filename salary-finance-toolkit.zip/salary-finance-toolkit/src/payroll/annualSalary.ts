/**
 * Annualise an hourly wage and pro-rate salaries.
 *
 * @packageDocumentation
 */

import { assertPositive, assertInRange, round } from '../utils/validation';

/** Input for {@link annualSalary}. */
export interface AnnualSalaryInput {
  /** Hourly wage. */
  hourlyRate: number;
  /** Hours worked per week (default `40`). */
  hoursPerWeek?: number;
  /** Paid weeks per year (default `52`). */
  weeksPerYear?: number;
}

/** Result returned by {@link annualSalary}. */
export interface AnnualSalaryResult {
  /** Annual gross salary. */
  annual: number;
  /** Monthly gross salary. */
  monthly: number;
  /** Weekly gross salary. */
  weekly: number;
}

/**
 * Annualises an hourly wage into yearly, monthly, and weekly figures.
 *
 * @param input - See {@link AnnualSalaryInput}.
 * @returns An {@link AnnualSalaryResult}.
 * @throws {@link ValidationError} If any value is not positive.
 *
 * @example
 * ```ts
 * annualSalary({ hourlyRate: 25 }); // -> { annual: 52000, monthly: 4333.33, weekly: 1000 }
 * ```
 */
export function annualSalary(input: AnnualSalaryInput): AnnualSalaryResult {
  const { hourlyRate, hoursPerWeek = 40, weeksPerYear = 52 } = input;
  assertPositive(hourlyRate, 'hourlyRate');
  assertPositive(hoursPerWeek, 'hoursPerWeek');
  assertPositive(weeksPerYear, 'weeksPerYear');

  const annual = round(hourlyRate * hoursPerWeek * weeksPerYear);
  return { annual, monthly: round(annual / 12), weekly: round(annual / weeksPerYear) };
}

/** Input for {@link proRataSalary}. */
export interface ProRataInput {
  /** Full-time-equivalent annual salary. */
  fullTimeSalary: number;
  /** Days actually worked in the period. */
  daysWorked: number;
  /** Total working days in the full period (default `260` = 52 weeks * 5). */
  totalWorkingDays?: number;
}

/** Result returned by {@link proRataSalary}. */
export interface ProRataResult {
  /** Pro-rated salary for the partial period. */
  proRated: number;
  /** Fraction of the full period worked (0–1). */
  fraction: number;
}

/**
 * Pro-rates a full-time salary for a partial working period (e.g. a new hire
 * who joins mid-year, or a part-time arrangement counted in days).
 *
 * @param input - See {@link ProRataInput}.
 * @returns A {@link ProRataResult}.
 * @throws {@link ValidationError} If inputs are invalid or `daysWorked`
 *   exceeds `totalWorkingDays`.
 *
 * @example
 * ```ts
 * proRataSalary({ fullTimeSalary: 60000, daysWorked: 130 });
 * // half a year -> { proRated: 30000, fraction: 0.5 }
 * ```
 */
export function proRataSalary(input: ProRataInput): ProRataResult {
  const { fullTimeSalary, daysWorked, totalWorkingDays = 260 } = input;
  assertPositive(fullTimeSalary, 'fullTimeSalary');
  assertPositive(totalWorkingDays, 'totalWorkingDays');
  assertInRange(daysWorked, 'daysWorked', 0, totalWorkingDays);

  const fraction = daysWorked / totalWorkingDays;
  return { proRated: round(fullTimeSalary * fraction), fraction: round(fraction, 4) };
}
