/**
 * Convert a periodic salary into an equivalent hourly wage.
 *
 * @packageDocumentation
 */

import { assertPositive, round } from '../utils/validation';

/** Input for {@link hourlyWage}. */
export interface HourlyWageInput {
  /** Annual gross salary. */
  annualSalary: number;
  /** Hours worked per week (default `40`). */
  hoursPerWeek?: number;
  /** Paid weeks per year (default `52`). */
  weeksPerYear?: number;
}

/** Result returned by {@link hourlyWage}. */
export interface HourlyWageResult {
  /** Equivalent hourly wage. */
  hourly: number;
  /** Equivalent daily wage (assuming a 5-day week). */
  daily: number;
  /** Equivalent weekly wage. */
  weekly: number;
  /** Equivalent monthly wage. */
  monthly: number;
  /** Total paid hours per year. */
  annualHours: number;
}

/**
 * Derives an hourly wage (and a few convenient breakdowns) from an annual
 * salary, given a working pattern.
 *
 * @param input - See {@link HourlyWageInput}.
 * @returns A {@link HourlyWageResult}.
 * @throws {@link ValidationError} If any value is not positive.
 *
 * @example
 * ```ts
 * hourlyWage({ annualSalary: 52000 });        // 40h * 52w = 2080h -> 25/hr
 * hourlyWage({ annualSalary: 60000, hoursPerWeek: 37.5 });
 * ```
 */
export function hourlyWage(input: HourlyWageInput): HourlyWageResult {
  const { annualSalary, hoursPerWeek = 40, weeksPerYear = 52 } = input;
  assertPositive(annualSalary, 'annualSalary');
  assertPositive(hoursPerWeek, 'hoursPerWeek');
  assertPositive(weeksPerYear, 'weeksPerYear');

  const annualHours = hoursPerWeek * weeksPerYear;
  const hourly = round(annualSalary / annualHours);
  const weekly = round(annualSalary / weeksPerYear);
  const daily = round(weekly / 5);
  const monthly = round(annualSalary / 12);

  return { hourly, daily, weekly, monthly, annualHours: round(annualHours) };
}
