/**
 * Overtime pay calculation.
 *
 * @packageDocumentation
 */

import { assertPositive, assertNonNegative, round } from '../utils/validation';

/** Input for {@link overtimePay}. */
export interface OvertimeInput {
  /** Base hourly rate. */
  hourlyRate: number;
  /** Number of overtime hours worked. */
  overtimeHours: number;
  /** Overtime multiplier (e.g. `1.5` for "time-and-a-half"). Default `1.5`. */
  multiplier?: number;
  /** Optional regular (non-overtime) hours, used to compute total pay. */
  regularHours?: number;
}

/** Result returned by {@link overtimePay}. */
export interface OvertimeResult {
  /** Effective overtime rate (`hourlyRate * multiplier`). */
  overtimeRate: number;
  /** Pay attributable to overtime hours only. */
  overtimePay: number;
  /** Pay attributable to regular hours (0 if `regularHours` omitted). */
  regularPay: number;
  /** Combined regular + overtime pay. */
  totalPay: number;
}

/**
 * Calculates overtime pay (and optionally total pay) from an hourly rate and a
 * number of overtime hours at a configurable multiplier.
 *
 * @param input - See {@link OvertimeInput}.
 * @returns An {@link OvertimeResult}.
 * @throws {@link ValidationError} If inputs are invalid.
 *
 * @example
 * ```ts
 * overtimePay({ hourlyRate: 20, overtimeHours: 5 });
 * // overtimeRate 30, overtimePay 150
 *
 * overtimePay({ hourlyRate: 20, overtimeHours: 5, regularHours: 40 });
 * // totalPay 950
 * ```
 */
export function overtimePay(input: OvertimeInput): OvertimeResult {
  const { hourlyRate, overtimeHours, multiplier = 1.5, regularHours = 0 } = input;
  assertPositive(hourlyRate, 'hourlyRate');
  assertNonNegative(overtimeHours, 'overtimeHours');
  assertPositive(multiplier, 'multiplier');
  assertNonNegative(regularHours, 'regularHours');

  const overtimeRate = round(hourlyRate * multiplier);
  const overtimePayValue = round(overtimeRate * overtimeHours);
  const regularPay = round(hourlyRate * regularHours);
  const totalPay = round(regularPay + overtimePayValue);

  return { overtimeRate, overtimePay: overtimePayValue, regularPay, totalPay };
}
