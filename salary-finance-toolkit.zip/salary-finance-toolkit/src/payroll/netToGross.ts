/**
 * Net → Gross salary conversion (the inverse of a flat-rate gross-to-net).
 *
 * @packageDocumentation
 */

import {
  assertPositive,
  assertInRange,
  assertNonNegative,
  round,
  ValidationError,
} from '../utils/validation';

/** Input for {@link netToGross}. */
export interface NetToGrossInput {
  /** Desired net (take-home) amount for the period. */
  net: number;
  /** Flat tax rate applied to gross, as a percentage (0–99.99). */
  taxRate?: number;
  /** Combined percentage of gross taken by other deductions (0–99.99). */
  deductionRate?: number;
  /** Flat deduction amounts that are independent of gross. */
  fixedDeductions?: number;
}

/** Result returned by {@link netToGross}. */
export interface NetToGrossResult {
  /** The gross required to achieve the requested net. */
  gross: number;
  /** Tax payable on that gross. */
  tax: number;
  /** Percentage-based deductions on that gross. */
  variableDeductions: number;
  /** Flat deductions echoed from input. */
  fixedDeductions: number;
  /** Resulting net (should equal the requested net within rounding). */
  net: number;
}

/**
 * Computes the gross salary required to leave a target net amount after a flat
 * tax rate, a flat percentage of other deductions, and fixed deductions.
 *
 * Derivation: `net = gross * (1 - (taxRate + deductionRate)/100) - fixed`, so
 * `gross = (net + fixed) / (1 - (taxRate + deductionRate)/100)`.
 *
 * @param input - See {@link NetToGrossInput}.
 * @returns A {@link NetToGrossResult}.
 * @throws {@link ValidationError} If inputs are invalid or the combined
 *   percentage deductions are >= 100% (which makes the target unreachable).
 *
 * @example
 * ```ts
 * netToGross({ net: 4000, taxRate: 20 });
 * // -> { gross: 5000, tax: 1000, ... }
 * ```
 */
export function netToGross(input: NetToGrossInput): NetToGrossResult {
  const { net, taxRate = 0, deductionRate = 0, fixedDeductions = 0 } = input;
  assertPositive(net, 'net');
  assertInRange(taxRate, 'taxRate', 0, 99.99);
  assertInRange(deductionRate, 'deductionRate', 0, 99.99);
  assertNonNegative(fixedDeductions, 'fixedDeductions');

  const retainedFraction = 1 - (taxRate + deductionRate) / 100;
  if (retainedFraction <= 0) {
    throw new ValidationError(
      'Combined taxRate and deductionRate must be below 100% to reach a positive net.',
    );
  }

  const gross = round((net + fixedDeductions) / retainedFraction);
  const tax = round((gross * taxRate) / 100);
  const variableDeductions = round((gross * deductionRate) / 100);
  const resultingNet = round(gross - tax - variableDeductions - fixedDeductions);

  return {
    gross,
    tax,
    variableDeductions,
    fixedDeductions: round(fixedDeductions),
    net: resultingNet,
  };
}
