/**
 * Gross → Net salary conversion.
 *
 * @packageDocumentation
 */

import { assertNonNegative, assertInRange, round } from '../utils/validation';

/** A single named deduction expressed either as a flat amount or a percentage. */
export interface Deduction {
  /** Human-readable label, e.g. `"Pension"`. */
  label: string;
  /** Flat amount to subtract from gross. Mutually exclusive with `percent`. */
  amount?: number;
  /** Percentage of gross to subtract (0–100). Mutually exclusive with `amount`. */
  percent?: number;
}

/** Input for {@link grossToNet}. */
export interface GrossToNetInput {
  /** Gross salary for the period. */
  gross: number;
  /**
   * Overall tax rate applied to gross, as a percentage (0–100).
   * For multi-band tax use the {@link progressiveTax} engine instead.
   */
  taxRate?: number;
  /** Additional named deductions (pension, insurance, etc.). */
  deductions?: Deduction[];
}

/** Result returned by {@link grossToNet}. */
export interface GrossToNetResult {
  /** Original gross amount. */
  gross: number;
  /** Tax amount derived from `taxRate`. */
  tax: number;
  /** Sum of all non-tax deductions. */
  totalDeductions: number;
  /** Itemised breakdown of every deduction (including tax). */
  breakdown: Array<{ label: string; amount: number }>;
  /** Net (take-home) amount: `gross - tax - totalDeductions`. */
  net: number;
}

/**
 * Converts a gross salary into a net (take-home) salary by subtracting a flat
 * tax rate plus any number of fixed or percentage-based deductions.
 *
 * The result never drops below zero; if deductions exceed gross, `net` is `0`.
 *
 * @param input - See {@link GrossToNetInput}.
 * @returns A {@link GrossToNetResult} with an itemised breakdown.
 * @throws {@link ValidationError} If any value is negative or out of range.
 *
 * @example
 * ```ts
 * grossToNet({
 *   gross: 5000,
 *   taxRate: 20,
 *   deductions: [{ label: 'Pension', percent: 5 }, { label: 'Union', amount: 25 }],
 * });
 * // -> { gross: 5000, tax: 1000, totalDeductions: 275, net: 3725, breakdown: [...] }
 * ```
 */
export function grossToNet(input: GrossToNetInput): GrossToNetResult {
  const { gross, taxRate = 0, deductions = [] } = input;
  assertNonNegative(gross, 'gross');
  assertInRange(taxRate, 'taxRate', 0, 100);

  const tax = round((gross * taxRate) / 100);
  const breakdown: Array<{ label: string; amount: number }> = [];
  if (tax > 0) breakdown.push({ label: 'Tax', amount: tax });

  let totalDeductions = 0;
  for (const d of deductions) {
    let amount = 0;
    if (typeof d.amount === 'number') {
      assertNonNegative(d.amount, `deduction "${d.label}" amount`);
      amount += d.amount;
    }
    if (typeof d.percent === 'number') {
      assertInRange(d.percent, `deduction "${d.label}" percent`, 0, 100);
      amount += (gross * d.percent) / 100;
    }
    amount = round(amount);
    totalDeductions += amount;
    breakdown.push({ label: d.label, amount });
  }
  totalDeductions = round(totalDeductions);

  const net = Math.max(0, round(gross - tax - totalDeductions));
  return { gross: round(gross), tax, totalDeductions, breakdown, net };
}
