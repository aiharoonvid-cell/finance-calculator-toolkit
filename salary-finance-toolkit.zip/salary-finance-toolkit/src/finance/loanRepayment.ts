/**
 * Loan repayment schedule (amortisation table).
 *
 * @packageDocumentation
 */

import { assertPositive, assertInRange, round } from '../utils/validation';
import { emi } from './emi';

/** A single row of an amortisation schedule. */
export interface AmortisationRow {
  /** 1-based payment number. */
  period: number;
  /** Portion of the payment applied to interest. */
  interest: number;
  /** Portion of the payment applied to principal. */
  principal: number;
  /** Remaining balance after this payment. */
  balance: number;
}

/** Input for {@link loanRepayment}. */
export interface LoanRepaymentInput {
  /** Loan principal. */
  principal: number;
  /** Annual interest rate as a percentage. */
  annualRate: number;
  /** Loan term in months. */
  months: number;
  /**
   * If `true`, the full per-period schedule is returned in `schedule`.
   * For long terms this can be large; defaults to `false`.
   */
  includeSchedule?: boolean;
}

/** Result returned by {@link loanRepayment}. */
export interface LoanRepaymentResult {
  /** Fixed monthly payment. */
  monthlyPayment: number;
  /** Total repaid over the term. */
  totalPayment: number;
  /** Total interest over the term. */
  totalInterest: number;
  /** Optional full amortisation schedule. */
  schedule?: AmortisationRow[];
}

/**
 * Builds a loan repayment summary and (optionally) a full amortisation
 * schedule, showing how each payment splits between interest and principal.
 *
 * @param input - See {@link LoanRepaymentInput}.
 * @returns A {@link LoanRepaymentResult}.
 * @throws {@link ValidationError} If inputs are invalid.
 *
 * @example
 * ```ts
 * loanRepayment({ principal: 10000, annualRate: 8, months: 12, includeSchedule: true });
 * ```
 */
export function loanRepayment(input: LoanRepaymentInput): LoanRepaymentResult {
  const { principal, annualRate, months, includeSchedule = false } = input;
  assertPositive(principal, 'principal');
  assertInRange(annualRate, 'annualRate', 0, 1000);
  assertPositive(months, 'months');

  const { emi: monthlyPayment, totalPayment, totalInterest } = emi({
    principal,
    annualRate,
    months,
  });

  const result: LoanRepaymentResult = { monthlyPayment, totalPayment, totalInterest };

  if (includeSchedule) {
    const r = annualRate / 100 / 12;
    const schedule: AmortisationRow[] = [];
    let balance = principal;
    for (let period = 1; period <= months; period++) {
      const interestPart = round(balance * r);
      // Final period absorbs rounding drift so the balance lands on zero.
      let principalPart = round(monthlyPayment - interestPart);
      if (period === months) principalPart = round(balance);
      balance = round(balance - principalPart);
      schedule.push({ period, interest: interestPart, principal: principalPart, balance: Math.max(0, balance) });
    }
    result.schedule = schedule;
  }

  return result;
}
