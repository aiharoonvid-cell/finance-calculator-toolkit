/**
 * Equated Monthly Instalment (EMI) for amortising loans.
 *
 * @packageDocumentation
 */

import { assertPositive, assertInRange, round } from '../utils/validation';

/** Input for {@link emi}. */
export interface EmiInput {
  /** Loan principal. */
  principal: number;
  /** Annual interest rate as a percentage. */
  annualRate: number;
  /** Loan term in months. */
  months: number;
}

/** Result returned by {@link emi}. */
export interface EmiResult {
  /** Fixed monthly instalment. */
  emi: number;
  /** Total amount repaid over the full term. */
  totalPayment: number;
  /** Total interest paid over the full term. */
  totalInterest: number;
}

/**
 * Computes the Equated Monthly Instalment using the standard amortisation
 * formula `EMI = P * r * (1+r)^n / ((1+r)^n - 1)`, where `r` is the monthly
 * rate and `n` is the number of months. Handles the zero-interest case.
 *
 * @param input - See {@link EmiInput}.
 * @returns An {@link EmiResult}.
 * @throws {@link ValidationError} If inputs are invalid.
 *
 * @example
 * ```ts
 * emi({ principal: 200000, annualRate: 6.5, months: 240 });
 * // emi ~= 1491.15
 * ```
 */
export function emi(input: EmiInput): EmiResult {
  const { principal, annualRate, months } = input;
  assertPositive(principal, 'principal');
  assertInRange(annualRate, 'annualRate', 0, 1000);
  assertPositive(months, 'months');

  const r = annualRate / 100 / 12;
  let monthly: number;
  if (r === 0) {
    monthly = principal / months;
  } else {
    const factor = (1 + r) ** months;
    monthly = (principal * r * factor) / (factor - 1);
  }

  const emiValue = round(monthly);
  const totalPayment = round(monthly * months);
  return {
    emi: emiValue,
    totalPayment,
    totalInterest: round(totalPayment - principal),
  };
}
