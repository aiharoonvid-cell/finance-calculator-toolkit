/**
 * Simple (non-compounding) interest.
 *
 * @packageDocumentation
 */

import { assertNonNegative, assertPositive, assertInRange, round } from '../utils/validation';

/** Input for {@link simpleInterest}. */
export interface SimpleInterestInput {
  /** Initial principal amount. */
  principal: number;
  /** Annual interest rate as a percentage. */
  rate: number;
  /** Term in years (may be fractional). */
  years: number;
}

/** Result returned by {@link simpleInterest}. */
export interface SimpleInterestResult {
  /** Interest earned: `P * r * t`. */
  interest: number;
  /** Final amount: `principal + interest`. */
  total: number;
}

/**
 * Computes simple interest using `I = P * r * t`.
 *
 * @param input - See {@link SimpleInterestInput}.
 * @returns A {@link SimpleInterestResult}.
 * @throws {@link ValidationError} If inputs are invalid.
 *
 * @example
 * ```ts
 * simpleInterest({ principal: 1000, rate: 5, years: 3 }); // interest 150, total 1150
 * ```
 */
export function simpleInterest(input: SimpleInterestInput): SimpleInterestResult {
  const { principal, rate, years } = input;
  assertNonNegative(principal, 'principal');
  assertInRange(rate, 'rate', 0, 1000);
  assertPositive(years, 'years');

  const interest = (principal * rate * years) / 100;
  return { interest: round(interest), total: round(principal + interest) };
}
