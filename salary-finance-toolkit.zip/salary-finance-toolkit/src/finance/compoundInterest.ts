/**
 * Compound interest with configurable compounding frequency.
 *
 * @packageDocumentation
 */

import { assertNonNegative, assertPositive, assertInRange, round } from '../utils/validation';
import { periodsPerYear, type Frequency } from '../utils/frequency';

/** Input for {@link compoundInterest}. */
export interface CompoundInterestInput {
  /** Initial principal amount. */
  principal: number;
  /** Annual nominal interest rate as a percentage (e.g. `5` for 5%). */
  rate: number;
  /** Investment term in years (may be fractional). */
  years: number;
  /** Compounding frequency. Default `'annual'`. */
  frequency?: Frequency;
}

/** Result returned by {@link compoundInterest}. */
export interface CompoundInterestResult {
  /** Final balance (principal + interest). */
  futureValue: number;
  /** Interest earned over the whole term. */
  interest: number;
  /** Effective annual rate implied by the nominal rate + frequency, as %. */
  effectiveAnnualRate: number;
}

/**
 * Computes compound interest using `A = P(1 + r/n)^(n*t)`.
 *
 * @param input - See {@link CompoundInterestInput}.
 * @returns A {@link CompoundInterestResult}.
 * @throws {@link ValidationError} If inputs are invalid.
 *
 * @example
 * ```ts
 * compoundInterest({ principal: 1000, rate: 5, years: 10, frequency: 'monthly' });
 * // futureValue ~= 1647.01
 * ```
 */
export function compoundInterest(input: CompoundInterestInput): CompoundInterestResult {
  const { principal, rate, years, frequency = 'annual' } = input;
  assertNonNegative(principal, 'principal');
  assertInRange(rate, 'rate', 0, 1000);
  assertPositive(years, 'years');

  const n = periodsPerYear(frequency);
  const r = rate / 100;
  const futureValue = principal * (1 + r / n) ** (n * years);
  const effectiveAnnualRate = ((1 + r / n) ** n - 1) * 100;

  return {
    futureValue: round(futureValue),
    interest: round(futureValue - principal),
    effectiveAnnualRate: round(effectiveAnnualRate, 4),
  };
}
