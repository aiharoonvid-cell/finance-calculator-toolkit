/**
 * Savings growth with optional regular contributions (future value of an
 * annuity plus a growing principal).
 *
 * @packageDocumentation
 */

import { assertNonNegative, assertPositive, assertInRange, round } from '../utils/validation';
import { periodsPerYear, type Frequency } from '../utils/frequency';

/** Input for {@link savingsGrowth}. */
export interface SavingsGrowthInput {
  /** Starting balance. */
  initialBalance: number;
  /** Recurring contribution made every period. */
  contribution: number;
  /** Annual interest rate as a percentage. */
  annualRate: number;
  /** Term in years. */
  years: number;
  /** Contribution / compounding frequency. Default `'monthly'`. */
  frequency?: Frequency;
  /** If `true`, contributions are made at the start of each period (annuity-due). */
  contributeAtStart?: boolean;
}

/** Result returned by {@link savingsGrowth}. */
export interface SavingsGrowthResult {
  /** Final balance. */
  futureValue: number;
  /** Sum of all contributions made (excluding the initial balance). */
  totalContributions: number;
  /** Total interest earned. */
  totalInterest: number;
}

/**
 * Projects savings growth from an initial balance plus regular contributions,
 * compounded at the contribution frequency.
 *
 * @param input - See {@link SavingsGrowthInput}.
 * @returns A {@link SavingsGrowthResult}.
 * @throws {@link ValidationError} If inputs are invalid.
 *
 * @example
 * ```ts
 * savingsGrowth({ initialBalance: 1000, contribution: 200, annualRate: 6, years: 10 });
 * ```
 */
export function savingsGrowth(input: SavingsGrowthInput): SavingsGrowthResult {
  const {
    initialBalance,
    contribution,
    annualRate,
    years,
    frequency = 'monthly',
    contributeAtStart = false,
  } = input;
  assertNonNegative(initialBalance, 'initialBalance');
  assertNonNegative(contribution, 'contribution');
  assertInRange(annualRate, 'annualRate', 0, 1000);
  assertPositive(years, 'years');

  const n = periodsPerYear(frequency);
  const periods = Math.round(n * years);
  const r = annualRate / 100 / n;

  let balance = initialBalance;
  for (let i = 0; i < periods; i++) {
    if (contributeAtStart) balance += contribution;
    balance *= 1 + r;
    if (!contributeAtStart) balance += contribution;
  }

  const totalContributions = round(contribution * periods);
  const futureValue = round(balance);
  return {
    futureValue,
    totalContributions,
    totalInterest: round(futureValue - initialBalance - totalContributions),
  };
}
