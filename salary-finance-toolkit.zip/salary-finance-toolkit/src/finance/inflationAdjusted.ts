/**
 * Inflation-adjusted (real) value of money.
 *
 * @packageDocumentation
 */

import { assertNonNegative, assertPositive, assertInRange, round } from '../utils/validation';

/** Input for {@link inflationAdjustedValue}. */
export interface InflationInput {
  /** Nominal amount today. */
  amount: number;
  /** Annual inflation rate as a percentage. */
  inflationRate: number;
  /** Number of years into the future. */
  years: number;
}

/** Result returned by {@link inflationAdjustedValue}. */
export interface InflationResult {
  /** Real value of `amount` after `years` of inflation (today's buying power). */
  realValue: number;
  /** Nominal amount needed in the future to match today's buying power. */
  nominalEquivalent: number;
  /** Total buying power lost, expressed as a percentage. */
  purchasingPowerLossPercent: number;
}

/**
 * Adjusts a nominal amount for inflation. `realValue` is what `amount` will be
 * worth in today's money after `years`; `nominalEquivalent` is how much you
 * would need in the future to preserve today's buying power.
 *
 * @param input - See {@link InflationInput}.
 * @returns An {@link InflationResult}.
 * @throws {@link ValidationError} If inputs are invalid.
 *
 * @example
 * ```ts
 * inflationAdjustedValue({ amount: 1000, inflationRate: 3, years: 10 });
 * // realValue ~= 744.09, nominalEquivalent ~= 1343.92
 * ```
 */
export function inflationAdjustedValue(input: InflationInput): InflationResult {
  const { amount, inflationRate, years } = input;
  assertNonNegative(amount, 'amount');
  assertInRange(inflationRate, 'inflationRate', 0, 1000);
  assertPositive(years, 'years');

  const factor = (1 + inflationRate / 100) ** years;
  const realValue = amount / factor;
  return {
    realValue: round(realValue),
    nominalEquivalent: round(amount * factor),
    purchasingPowerLossPercent: round((1 - realValue / amount) * 100, 2),
  };
}
