/**
 * Core time-value-of-money helpers: future value, present value, CAGR, ROI,
 * and the rule-of-72 doubling-time approximation.
 *
 * @packageDocumentation
 */

import { assertNonNegative, assertPositive, assertInRange, round } from '../utils/validation';

/** Input for {@link futureValue}. */
export interface FutureValueInput {
  /** Present amount. */
  presentValue: number;
  /** Annual rate as a percentage. */
  rate: number;
  /** Number of years. */
  years: number;
}

/**
 * Future value of a lump sum: `FV = PV * (1 + r)^t`.
 *
 * @param input - See {@link FutureValueInput}.
 * @returns The future value, rounded to 2 dp.
 * @throws {@link ValidationError} If inputs are invalid.
 *
 * @example
 * ```ts
 * futureValue({ presentValue: 1000, rate: 7, years: 10 }); // ~= 1967.15
 * ```
 */
export function futureValue(input: FutureValueInput): number {
  const { presentValue, rate, years } = input;
  assertNonNegative(presentValue, 'presentValue');
  assertInRange(rate, 'rate', 0, 1000);
  assertPositive(years, 'years');
  return round(presentValue * (1 + rate / 100) ** years);
}

/** Input for {@link presentValue}. */
export interface PresentValueInput {
  /** Future amount. */
  futureValue: number;
  /** Annual discount rate as a percentage. */
  rate: number;
  /** Number of years. */
  years: number;
}

/**
 * Present value of a future lump sum: `PV = FV / (1 + r)^t`.
 *
 * @param input - See {@link PresentValueInput}.
 * @returns The present value, rounded to 2 dp.
 * @throws {@link ValidationError} If inputs are invalid.
 *
 * @example
 * ```ts
 * presentValue({ futureValue: 1967.15, rate: 7, years: 10 }); // ~= 1000
 * ```
 */
export function presentValue(input: PresentValueInput): number {
  const { futureValue: fv, rate, years } = input;
  assertNonNegative(fv, 'futureValue');
  assertInRange(rate, 'rate', 0, 1000);
  assertPositive(years, 'years');
  return round(fv / (1 + rate / 100) ** years);
}

/** Input for {@link cagr}. */
export interface CagrInput {
  /** Starting value. */
  beginningValue: number;
  /** Ending value. */
  endingValue: number;
  /** Number of years between the two values. */
  years: number;
}

/**
 * Compound Annual Growth Rate: `CAGR = (end / begin)^(1/years) - 1`, returned
 * as a percentage.
 *
 * @param input - See {@link CagrInput}.
 * @returns The CAGR as a percentage, rounded to 4 dp.
 * @throws {@link ValidationError} If inputs are invalid.
 *
 * @example
 * ```ts
 * cagr({ beginningValue: 1000, endingValue: 2000, years: 10 }); // ~= 7.1773
 * ```
 */
export function cagr(input: CagrInput): number {
  const { beginningValue, endingValue, years } = input;
  assertPositive(beginningValue, 'beginningValue');
  assertPositive(endingValue, 'endingValue');
  assertPositive(years, 'years');
  return round(((endingValue / beginningValue) ** (1 / years) - 1) * 100, 4);
}

/** Input for {@link roi}. */
export interface RoiInput {
  /** Amount invested. */
  initialInvestment: number;
  /** Final value of the investment (or net proceeds). */
  finalValue: number;
}

/** Result returned by {@link roi}. */
export interface RoiResult {
  /** Net gain or loss (`finalValue - initialInvestment`). */
  netProfit: number;
  /** Return on investment as a percentage. */
  roiPercent: number;
}

/**
 * Return on Investment: `ROI = (final - initial) / initial * 100`.
 *
 * @param input - See {@link RoiInput}.
 * @returns An {@link RoiResult}.
 * @throws {@link ValidationError} If inputs are invalid.
 *
 * @example
 * ```ts
 * roi({ initialInvestment: 1000, finalValue: 1250 }); // netProfit 250, roiPercent 25
 * ```
 */
export function roi(input: RoiInput): RoiResult {
  const { initialInvestment, finalValue } = input;
  assertPositive(initialInvestment, 'initialInvestment');
  assertNonNegative(finalValue, 'finalValue');
  const netProfit = round(finalValue - initialInvestment);
  return { netProfit, roiPercent: round((netProfit / initialInvestment) * 100) };
}

/**
 * Estimates the number of years for an investment to double using the
 * "Rule of 72" approximation (`72 / rate`).
 *
 * @param rate - Annual growth rate as a percentage (must be > 0).
 * @returns Approximate doubling time in years, rounded to 2 dp.
 * @throws {@link ValidationError} If the rate is not positive.
 *
 * @example
 * ```ts
 * ruleOf72(8); // 9
 * ```
 */
export function ruleOf72(rate: number): number {
  assertPositive(rate, 'rate');
  return round(72 / rate);
}
