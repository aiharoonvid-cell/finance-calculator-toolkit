/**
 * Ratio simplification and splitting.
 *
 * @packageDocumentation
 */

import { assertPositive, assertNonNegative, round, ValidationError } from '../utils/validation';

/** Result returned by {@link ratio}. */
export interface RatioResult {
  /** The two terms simplified to their smallest whole-number form. */
  simplified: [number, number];
  /** A human-readable string, e.g. `"3:2"`. */
  asString: string;
  /** The ratio expressed as a single decimal (`a / b`). */
  decimal: number;
}

/**
 * Computes the greatest common divisor of two integers (Euclid's algorithm).
 *
 * @internal
 */
function gcd(a: number, b: number): number {
  let x = Math.abs(a);
  let y = Math.abs(b);
  while (y) {
    [x, y] = [y, x % y];
  }
  return x || 1;
}

/**
 * Simplifies the ratio `a : b` to its smallest whole-number terms. Inputs are
 * scaled to integers first, so decimal inputs such as `1.5 : 0.5` work.
 *
 * @param a - First term (non-negative; at least one term must be > 0).
 * @param b - Second term (non-negative).
 * @returns A {@link RatioResult}.
 * @throws {@link ValidationError} If inputs are invalid or both are `0`.
 *
 * @example
 * ```ts
 * ratio(1920, 1080); // simplified [16, 9], asString '16:9'
 * ratio(1.5, 0.5);   // simplified [3, 1], asString '3:1'
 * ```
 */
export function ratio(a: number, b: number): RatioResult {
  assertNonNegative(a, 'a');
  assertNonNegative(b, 'b');
  if (a === 0 && b === 0) {
    throw new ValidationError('At least one of "a" or "b" must be greater than 0.');
  }

  // Scale to integers to support decimal inputs (up to 6 dp of precision).
  const scale = 10 ** 6;
  const ai = Math.round(a * scale);
  const bi = Math.round(b * scale);
  const divisor = gcd(ai, bi);
  const simplified: [number, number] = [ai / divisor, bi / divisor];

  return {
    simplified,
    asString: `${simplified[0]}:${simplified[1]}`,
    decimal: b === 0 ? Infinity : round(a / b, 4),
  };
}

/** Result returned by {@link splitByRatio}. */
export interface SplitResult {
  /** The allocated amounts, in the same order as the input weights. */
  parts: number[];
}

/**
 * Splits a total amount across several parties in proportion to a set of
 * weights. Useful for profit-sharing, expense-splitting, and tip pooling.
 *
 * @param total   - The amount to distribute (must be positive).
 * @param weights - Relative weights (each non-negative; sum must be > 0).
 * @returns A {@link SplitResult} whose parts sum to `total` (within rounding).
 * @throws {@link ValidationError} If inputs are invalid.
 *
 * @example
 * ```ts
 * splitByRatio(1000, [3, 2]); // parts [600, 400]
 * ```
 */
export function splitByRatio(total: number, weights: number[]): SplitResult {
  assertPositive(total, 'total');
  if (!Array.isArray(weights) || weights.length === 0) {
    throw new ValidationError('"weights" must be a non-empty array.');
  }
  weights.forEach((w, i) => assertNonNegative(w, `weights[${i}]`));

  const sum = weights.reduce((acc, w) => acc + w, 0);
  if (sum === 0) {
    throw new ValidationError('The sum of "weights" must be greater than 0.');
  }

  const parts = weights.map((w) => round((total * w) / sum));
  // Push any rounding remainder onto the last part so the parts sum to total.
  const allocated = parts.reduce((acc, p) => acc + p, 0);
  parts[parts.length - 1] = round(parts[parts.length - 1] + (total - allocated));

  return { parts };
}
