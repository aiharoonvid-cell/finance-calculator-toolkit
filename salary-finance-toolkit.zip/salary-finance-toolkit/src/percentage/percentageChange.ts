/**
 * Percentage change, increase, and decrease helpers.
 *
 * @packageDocumentation
 */

import { assertNumber, assertNonNegative, ValidationError, round } from '../utils/validation';

/**
 * Computes the percentage change from `oldValue` to `newValue`:
 * `(newValue - oldValue) / |oldValue| * 100`. A positive result is an
 * increase, a negative result a decrease.
 *
 * @param oldValue - The original value (must be non-zero).
 * @param newValue - The updated value.
 * @returns The signed percentage change, rounded to 2 dp.
 * @throws {@link ValidationError} If `oldValue` is `0` or inputs aren't numbers.
 *
 * @example
 * ```ts
 * percentageChange(200, 250); // 25
 * percentageChange(250, 200); // -20
 * ```
 */
export function percentageChange(oldValue: number, newValue: number): number {
  assertNumber(oldValue, 'oldValue');
  assertNumber(newValue, 'newValue');
  if (oldValue === 0) {
    throw new ValidationError('"oldValue" must not be 0 (percentage change is undefined).');
  }
  return round(((newValue - oldValue) / Math.abs(oldValue)) * 100, 2);
}

/**
 * Increases `value` by `percent`%.
 *
 * @param value   - The base value.
 * @param percent - The percentage to add (non-negative).
 * @returns The increased value, rounded to 2 dp.
 * @throws {@link ValidationError} If inputs are invalid.
 *
 * @example
 * ```ts
 * percentageIncrease(200, 25); // 250
 * ```
 */
export function percentageIncrease(value: number, percent: number): number {
  assertNumber(value, 'value');
  assertNonNegative(percent, 'percent');
  return round(value * (1 + percent / 100), 2);
}

/**
 * Decreases `value` by `percent`%.
 *
 * @param value   - The base value.
 * @param percent - The percentage to subtract (0–100).
 * @returns The decreased value, rounded to 2 dp.
 * @throws {@link ValidationError} If inputs are invalid.
 *
 * @example
 * ```ts
 * percentageDecrease(200, 20); // 160
 * ```
 */
export function percentageDecrease(value: number, percent: number): number {
  assertNumber(value, 'value');
  assertNonNegative(percent, 'percent');
  return round(value * (1 - percent / 100), 2);
}

/**
 * Returns `percent`% of `value` (i.e. "what is X% of Y").
 *
 * @param value   - The base value.
 * @param percent - The percentage to take.
 * @returns `value * percent / 100`, rounded to 2 dp.
 * @throws {@link ValidationError} If inputs aren't numbers.
 *
 * @example
 * ```ts
 * percentageOf(200, 15); // 30
 * ```
 */
export function percentageOf(value: number, percent: number): number {
  assertNumber(value, 'value');
  assertNumber(percent, 'percent');
  return round((value * percent) / 100, 2);
}

/**
 * Returns what percentage `part` is of `whole` (i.e. "X is what % of Y").
 *
 * @param part  - The portion.
 * @param whole - The total (must be non-zero).
 * @returns `part / whole * 100`, rounded to 2 dp.
 * @throws {@link ValidationError} If `whole` is `0` or inputs aren't numbers.
 *
 * @example
 * ```ts
 * whatPercentageOf(30, 200); // 15
 * ```
 */
export function whatPercentageOf(part: number, whole: number): number {
  assertNumber(part, 'part');
  assertNumber(whole, 'whole');
  if (whole === 0) {
    throw new ValidationError('"whole" must not be 0.');
  }
  return round((part / whole) * 100, 2);
}
