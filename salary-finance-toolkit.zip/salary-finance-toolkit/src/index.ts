/**
 * salary-finance-toolkit
 * ----------------------
 * A dependency-free TypeScript/JavaScript toolkit of finance, payroll, salary,
 * tax, and percentage calculators.
 *
 * Interactive calculators and extended documentation are available at
 * {@link https://uifcalculator.com | uifcalculator.com}.
 *
 * @packageDocumentation
 */

// Shared utilities (ValidationError, round, frequency helpers, ...).
export * from './utils';

// Calculator modules.
export * from './payroll';
export * from './finance';
export * from './tax';
export * from './percentage';

/** Library version, kept in sync with package.json. */
export const VERSION = '1.0.0';
