/**
 * Percentage & ratio examples. Run with:  npx tsx examples/percentage.example.ts
 */
import {
  percentageChange,
  percentageIncrease,
  percentageDecrease,
  percentageOf,
  whatPercentageOf,
  ratio,
  splitByRatio,
} from '../src/index';

console.log('percentageChange 200 -> 250:', percentageChange(200, 250), '%');
console.log('percentageIncrease 200 +25%:', percentageIncrease(200, 25));
console.log('percentageDecrease 200 -20%:', percentageDecrease(200, 20));
console.log('percentageOf 15% of 200:', percentageOf(200, 15));
console.log('whatPercentageOf 30 of 200:', whatPercentageOf(30, 200), '%');
console.log('ratio 1920:1080 ->', ratio(1920, 1080).asString);
console.log('splitByRatio 1000 by [3,2]:', splitByRatio(1000, [3, 2]));
