/**
 * Finance examples. Run with:  npx tsx examples/finance.example.ts
 */
import {
  compoundInterest,
  simpleInterest,
  emi,
  loanRepayment,
  savingsGrowth,
  inflationAdjustedValue,
  futureValue,
  presentValue,
  cagr,
  roi,
  ruleOf72,
} from '../src/index';

console.log('compoundInterest:', compoundInterest({ principal: 1000, rate: 5, years: 10, frequency: 'monthly' }));
console.log('simpleInterest:', simpleInterest({ principal: 1000, rate: 5, years: 3 }));
console.log('emi:', emi({ principal: 200000, annualRate: 6.5, months: 240 }));
console.log('loanRepayment (summary):', loanRepayment({ principal: 10000, annualRate: 8, months: 12 }));
console.log('savingsGrowth:', savingsGrowth({ initialBalance: 1000, contribution: 200, annualRate: 6, years: 10 }));
console.log('inflationAdjustedValue:', inflationAdjustedValue({ amount: 1000, inflationRate: 3, years: 10 }));
console.log('futureValue:', futureValue({ presentValue: 1000, rate: 7, years: 10 }));
console.log('presentValue:', presentValue({ futureValue: 1967.15, rate: 7, years: 10 }));
console.log('cagr:', cagr({ beginningValue: 1000, endingValue: 2000, years: 10 }), '%');
console.log('roi:', roi({ initialInvestment: 1000, finalValue: 1250 }));
console.log('ruleOf72:', ruleOf72(8), 'years to double');
