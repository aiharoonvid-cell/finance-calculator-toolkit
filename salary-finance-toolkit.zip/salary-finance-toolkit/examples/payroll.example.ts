/**
 * Payroll examples. Run with:  npx tsx examples/payroll.example.ts
 */
import {
  grossToNet,
  netToGross,
  hourlyWage,
  overtimePay,
  annualSalary,
  proRataSalary,
  payPeriodSalary,
} from '../src/index';

console.log('grossToNet:', grossToNet({
  gross: 5000,
  taxRate: 20,
  deductions: [{ label: 'Pension', percent: 5 }, { label: 'Union', amount: 25 }],
}));

console.log('netToGross:', netToGross({ net: 4000, taxRate: 20 }));

console.log('hourlyWage:', hourlyWage({ annualSalary: 52000 }));

console.log('overtimePay:', overtimePay({ hourlyRate: 20, overtimeHours: 5, regularHours: 40 }));

console.log('annualSalary:', annualSalary({ hourlyRate: 25 }));

console.log('proRataSalary:', proRataSalary({ fullTimeSalary: 60000, daysWorked: 130 }));

console.log('payPeriodSalary:', payPeriodSalary({ annualSalary: 52000, frequency: 'biweekly' }));
