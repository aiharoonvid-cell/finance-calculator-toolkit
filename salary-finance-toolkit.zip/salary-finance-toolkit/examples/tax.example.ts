/**
 * Tax examples. Run with:  npx tsx examples/tax.example.ts
 *
 * The brackets below are illustrative only — supply your own jurisdiction's
 * bands. Live, country-specific calculators live at https://uifcalculator.com.
 */
import { progressiveTax, effectiveTaxRate, marginalTaxRate, type TaxBracket } from '../src/index';

const brackets: TaxBracket[] = [
  { from: 0, to: 12000, rate: 0 },
  { from: 12000, to: 40000, rate: 20 },
  { from: 40000, rate: 40 },
];

const result = progressiveTax({ income: 50000, brackets });
console.log('progressiveTax:', result);
console.log('effectiveTaxRate:', effectiveTaxRate({ income: 50000, taxPaid: result.totalTax }), '%');
console.log('marginalTaxRate:', marginalTaxRate({ income: 50000, brackets }), '%');
