import { describe, it, expect } from 'vitest';
import {
  compoundInterest,
  simpleInterest,
  emi,
  loanRepayment,
  savingsGrowth,
  inflationAdjustedValue,
  futureValue,
  presentValue,
  cagr,
  roi,
  ruleOf72,
  ValidationError,
} from '../src/index';

describe('finance', () => {
  it('compoundInterest matches A = P(1+r/n)^(nt)', () => {
    const r = compoundInterest({ principal: 1000, rate: 5, years: 10, frequency: 'monthly' });
    expect(r.futureValue).toBeCloseTo(1647.01, 1);
    expect(r.interest).toBeCloseTo(647.01, 1);
  });

  it('simpleInterest matches I = Prt', () => {
    const r = simpleInterest({ principal: 1000, rate: 5, years: 3 });
    expect(r.interest).toBe(150);
    expect(r.total).toBe(1150);
  });

  it('emi computes the standard amortising payment', () => {
    const r = emi({ principal: 200000, annualRate: 6.5, months: 240 });
    expect(r.emi).toBeCloseTo(1491.15, 0);
    expect(r.totalInterest).toBeGreaterThan(0);
  });

  it('emi handles zero interest', () => {
    expect(emi({ principal: 1200, annualRate: 0, months: 12 }).emi).toBe(100);
  });

  it('loanRepayment schedule amortises to zero', () => {
    const r = loanRepayment({ principal: 10000, annualRate: 8, months: 12, includeSchedule: true });
    expect(r.schedule).toHaveLength(12);
    expect(r.schedule?.[11].balance).toBe(0);
  });

  it('savingsGrowth accumulates contributions plus interest', () => {
    const r = savingsGrowth({ initialBalance: 1000, contribution: 200, annualRate: 6, years: 10 });
    expect(r.totalContributions).toBe(24000);
    expect(r.futureValue).toBeGreaterThan(25000);
  });

  it('inflationAdjustedValue reduces real buying power', () => {
    const r = inflationAdjustedValue({ amount: 1000, inflationRate: 3, years: 10 });
    expect(r.realValue).toBeCloseTo(744.09, 0);
    expect(r.nominalEquivalent).toBeCloseTo(1343.92, 0);
  });

  it('futureValue and presentValue are inverses', () => {
    const fv = futureValue({ presentValue: 1000, rate: 7, years: 10 });
    expect(presentValue({ futureValue: fv, rate: 7, years: 10 })).toBeCloseTo(1000, 0);
  });

  it('cagr computes compound annual growth', () => {
    expect(cagr({ beginningValue: 1000, endingValue: 2000, years: 10 })).toBeCloseTo(7.1773, 2);
  });

  it('roi computes return percentage', () => {
    const r = roi({ initialInvestment: 1000, finalValue: 1250 });
    expect(r.netProfit).toBe(250);
    expect(r.roiPercent).toBe(25);
  });

  it('ruleOf72 approximates doubling time', () => {
    expect(ruleOf72(8)).toBe(9);
  });

  it('rejects invalid input', () => {
    expect(() => simpleInterest({ principal: -1, rate: 5, years: 1 })).toThrow(ValidationError);
    expect(() => compoundInterest({ principal: 100, rate: 5, years: 0 })).toThrow(ValidationError);
  });
});
