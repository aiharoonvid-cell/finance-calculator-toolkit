import { describe, it, expect } from 'vitest';
import {
  grossToNet,
  netToGross,
  hourlyWage,
  overtimePay,
  annualSalary,
  proRataSalary,
  payPeriodSalary,
  ValidationError,
} from '../src/index';

describe('payroll', () => {
  describe('grossToNet', () => {
    it('applies tax and mixed deductions', () => {
      const r = grossToNet({
        gross: 5000,
        taxRate: 20,
        deductions: [{ label: 'Pension', percent: 5 }, { label: 'Union', amount: 25 }],
      });
      expect(r.tax).toBe(1000);
      expect(r.totalDeductions).toBe(275);
      expect(r.net).toBe(3725);
      expect(r.breakdown).toHaveLength(3);
    });

    it('never returns a negative net', () => {
      expect(grossToNet({ gross: 100, taxRate: 90, deductions: [{ label: 'x', amount: 50 }] }).net).toBe(0);
    });

    it('rejects an out-of-range tax rate', () => {
      expect(() => grossToNet({ gross: 1000, taxRate: 150 })).toThrow(ValidationError);
    });
  });

  describe('netToGross', () => {
    it('is the inverse of a flat-rate gross-to-net', () => {
      expect(netToGross({ net: 4000, taxRate: 20 }).gross).toBe(5000);
    });

    it('throws when deductions reach 100%', () => {
      expect(() => netToGross({ net: 1000, taxRate: 60, deductionRate: 40 })).toThrow(ValidationError);
    });
  });

  describe('hourlyWage', () => {
    it('derives 25/hr from a 52k salary at 40h/week', () => {
      expect(hourlyWage({ annualSalary: 52000 }).hourly).toBe(25);
    });
  });

  describe('overtimePay', () => {
    it('uses time-and-a-half by default', () => {
      const r = overtimePay({ hourlyRate: 20, overtimeHours: 5 });
      expect(r.overtimeRate).toBe(30);
      expect(r.overtimePay).toBe(150);
    });
    it('adds regular pay when provided', () => {
      expect(overtimePay({ hourlyRate: 20, overtimeHours: 5, regularHours: 40 }).totalPay).toBe(950);
    });
  });

  describe('annualSalary', () => {
    it('annualises an hourly rate', () => {
      expect(annualSalary({ hourlyRate: 25 }).annual).toBe(52000);
    });
  });

  describe('proRataSalary', () => {
    it('pro-rates half a year', () => {
      const r = proRataSalary({ fullTimeSalary: 60000, daysWorked: 130 });
      expect(r.proRated).toBe(30000);
      expect(r.fraction).toBe(0.5);
    });
    it('rejects more days than the period', () => {
      expect(() => proRataSalary({ fullTimeSalary: 60000, daysWorked: 300 })).toThrow(ValidationError);
    });
  });

  describe('payPeriodSalary', () => {
    it('splits across biweekly periods', () => {
      const r = payPeriodSalary({ annualSalary: 52000, frequency: 'biweekly' });
      expect(r.perPeriod).toBe(2000);
      expect(r.periodsPerYear).toBe(26);
    });
  });
});
