import { describe, it, expect } from 'vitest';
import {
  progressiveTax,
  effectiveTaxRate,
  marginalTaxRate,
  ValidationError,
  type TaxBracket,
} from '../src/index';

const brackets: TaxBracket[] = [
  { from: 0, to: 12000, rate: 0 },
  { from: 12000, to: 40000, rate: 20 },
  { from: 40000, rate: 40 },
];

describe('tax', () => {
  it('progressiveTax taxes each slice at its marginal rate', () => {
    const r = progressiveTax({ income: 50000, brackets });
    // 0 on first 12k, 20% on next 28k = 5600, 40% on last 10k = 4000
    expect(r.totalTax).toBe(9600);
    expect(r.netIncome).toBe(40400);
    expect(r.marginalRate).toBe(40);
    expect(r.effectiveRate).toBe(19.2);
    expect(r.breakdown).toHaveLength(3);
  });

  it('handles income below the first threshold', () => {
    expect(progressiveTax({ income: 10000, brackets }).totalTax).toBe(0);
  });

  it('rejects non-contiguous brackets', () => {
    expect(() =>
      progressiveTax({ income: 100, brackets: [{ from: 0, to: 100, rate: 10 }, { from: 200, rate: 20 }] }),
    ).toThrow(ValidationError);
  });

  it('effectiveTaxRate divides tax by income', () => {
    expect(effectiveTaxRate({ income: 50000, taxPaid: 9600 })).toBe(19.2);
  });

  it('marginalTaxRate returns the top reached bracket', () => {
    expect(marginalTaxRate({ income: 50000, brackets })).toBe(40);
    expect(marginalTaxRate({ income: 20000, brackets })).toBe(20);
  });
});
