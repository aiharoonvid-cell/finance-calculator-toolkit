import { describe, it, expect } from 'vitest';
import {
  percentageChange,
  percentageIncrease,
  percentageDecrease,
  percentageOf,
  whatPercentageOf,
  ratio,
  splitByRatio,
  ValidationError,
} from '../src/index';

describe('percentage', () => {
  it('percentageChange is signed', () => {
    expect(percentageChange(200, 250)).toBe(25);
    expect(percentageChange(250, 200)).toBe(-20);
  });
  it('percentageChange rejects a zero base', () => {
    expect(() => percentageChange(0, 100)).toThrow(ValidationError);
  });
  it('increase / decrease', () => {
    expect(percentageIncrease(200, 25)).toBe(250);
    expect(percentageDecrease(200, 20)).toBe(160);
  });
  it('percentageOf and whatPercentageOf are consistent', () => {
    expect(percentageOf(200, 15)).toBe(30);
    expect(whatPercentageOf(30, 200)).toBe(15);
  });
  it('ratio simplifies', () => {
    expect(ratio(1920, 1080).asString).toBe('16:9');
    expect(ratio(1.5, 0.5).asString).toBe('3:1');
  });
  it('splitByRatio distributes the full total', () => {
    const r = splitByRatio(1000, [3, 2]);
    expect(r.parts).toEqual([600, 400]);
    expect(r.parts.reduce((a, b) => a + b, 0)).toBe(1000);
  });
});
